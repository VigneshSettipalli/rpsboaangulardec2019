import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JwtinterceptorComponent } from './jwtinterceptor.component';

describe('JwtinterceptorComponent', () => {
  let component: JwtinterceptorComponent;
  let fixture: ComponentFixture<JwtinterceptorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JwtinterceptorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JwtinterceptorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
