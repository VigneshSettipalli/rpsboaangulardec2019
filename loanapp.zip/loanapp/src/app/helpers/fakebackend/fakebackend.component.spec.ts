import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FakebackendComponent } from './fakebackend.component';

describe('FakebackendComponent', () => {
  let component: FakebackendComponent;
  let fixture: ComponentFixture<FakebackendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FakebackendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FakebackendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
