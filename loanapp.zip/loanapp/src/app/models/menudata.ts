import {Item, Menu} from "./menu";


export  let menuData:Menu[]=[
  new Menu('Home', 'pi pi-fw pi-home','Home',[new Item('Add-Loan',

    'pi pi-fw pi-share-alt','Home/Add-Loan'),
    new Item('Add-Offer','pi pi-fw pi-pencil','Home/Add-Offer')

  ]),

  new Menu('Loan', 'pi pi-fw pi-plus','Loan',[new Item('Apply',

    'pi pi-fw pi-share-alt','Loan/Apply'),
    new Item('Eligibility-Check','pi pi-fw pi-pencil','Loan/Eligibility-Check'),
    new Item('Loan-Status','pi pi-fw pi-cog','Loan/Loan-Status'),
    new Item('Pay-EMI','pi pi-fw pi-key','Loan/Pay-EMI')
  ]),



  new Menu('Alerts', 'pi pi-fw pi-bell','Alerts',[ ]),
  new Menu('Admin', 'pi pi-fw pi-sign-out','Admin',[ ]),


]
