import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from "./home/home.component";
import {AboutloanComponent} from "./home/aboutloan/aboutloan.component";
import {AboutofferComponent} from "./home/aboutoffer/aboutoffer.component";
import {LoanComponent} from "./loan/loan.component";
import {LoginComponent} from "./login/login.component";
import {AlertsComponent} from "./alerts/alerts.component";
import {AdminComponent} from "./admin/admin.component";
import {ApplyComponent} from "./loan/apply/apply.component";
import {EligibilityComponent} from "./loan/eligibility/eligibility.component";
import {StatusComponent} from "./loan/status/status.component";
import {EmiComponent} from "./loan/emi/emi.component";
import {RegisterComponent} from "./register/register.component";
import {AuthGuard} from "./helpers/authguard/authguard.component";


const routes: Routes = [
  {
    path:'',
    component:LoginComponent

  },


  {

    path: 'Home',
    component: HomeComponent,
    canActivate: [ AuthGuard ],

    children: [
      {path: 'Add-Loan', component: AboutloanComponent},
      {path: 'Add-Offer', component: AboutofferComponent}


    ]
  },
  {
    path: 'Loan',
    component: LoanComponent,
    canActivate: [ AuthGuard],
   children: [
  {path: 'Apply', component: ApplyComponent},
  {path: 'Eligibility-Check', component: EligibilityComponent},
     {path: 'Loan-Status', component: StatusComponent},
     {path: 'Pay-EMI', component:EmiComponent }

]
  },

  { path: 'register', component: RegisterComponent },
  {
    path: 'Alerts',
    component: AlertsComponent,
    canActivate: [ AuthGuard ]
  },
  {
    path: 'Admin',
    component: AdminComponent,
    canActivate: [ AuthGuard ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
