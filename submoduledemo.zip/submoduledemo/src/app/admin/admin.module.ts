import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AdminRoutingModule} from "./admin-routing.module";
import { InboxComponent } from './inbox/inbox.component';
import { ReportsComponent } from './reports/reports.component';
import {AlertComponent} from "./alert/alert.component";



@NgModule({
  declarations: [InboxComponent, AlertComponent, ReportsComponent],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
