import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutoffer',
  templateUrl: './aboutoffer.component.html',
  styleUrls: ['./aboutoffer.component.css']
})
export class AboutofferComponent implements OnInit {

  constructor() {
    console.log('About Offer');
  }

  ngOnInit() {
  }

}
