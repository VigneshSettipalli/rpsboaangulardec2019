import { Component } from '@angular/core';

@Component({
  selector: 'loan-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'loanapp';
  //one way binding
  private logoPath='./assets/boa.jpg';
  private banner1='./assets/banner.jpg';
  private banner2='./assets/banner2.jpg';
}
