import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutloan',
  templateUrl: './aboutloan.component.html',
  styleUrls: ['./aboutloan.component.css']
})
export class AboutloanComponent implements OnInit {

  constructor() {
    console.log('About Loan');
  }

  ngOnInit() {
  }

}
