import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';



@Component({ selector: 'alert', templateUrl: 'alerts.component.html' })
export class AlertsComponent {

}
